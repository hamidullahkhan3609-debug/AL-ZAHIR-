import { Phone, MapPin, Mail } from 'lucide-react';

interface FooterProps {
  onNavigate: (page: string) => void;
}

export default function Footer({ onNavigate }: FooterProps) {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4 text-yellow-400">AL-ZAHIR ETEA Coaching Academy</h3>
            <p className="text-gray-300 text-sm leading-relaxed">
              Preparing talented students for the ETEA Center of Excellence scholarship test to secure admission to top government institutions.
            </p>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-4 text-yellow-400">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => { onNavigate('about'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="text-gray-300 hover:text-yellow-400 transition-colors text-sm"
                >
                  About Us
                </button>
              </li>
              <li>
                <button
                  onClick={() => { onNavigate('classes'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="text-gray-300 hover:text-yellow-400 transition-colors text-sm"
                >
                  Classes & Subjects
                </button>
              </li>
              <li>
                <button
                  onClick={() => { onNavigate('faculty'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="text-gray-300 hover:text-yellow-400 transition-colors text-sm"
                >
                  Faculty
                </button>
              </li>
              <li>
                <button
                  onClick={() => { onNavigate('contact'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="text-gray-300 hover:text-yellow-400 transition-colors text-sm"
                >
                  Contact Us
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-4 text-yellow-400">Contact Information</h4>
            <ul className="space-y-3">
              <li className="flex items-start space-x-3">
                <MapPin className="w-5 h-5 text-yellow-400 flex-shrink-0 mt-0.5" />
                <span className="text-gray-300 text-sm">Mama Khel, Bannu, Khyber Pakhtunkhwa, Pakistan</span>
              </li>
              <li className="flex items-center space-x-3">
                <Phone className="w-5 h-5 text-yellow-400 flex-shrink-0" />
                <span className="text-gray-300 text-sm">03329746471</span>
              </li>
              <li className="flex items-center space-x-3">
                <Mail className="w-5 h-5 text-yellow-400 flex-shrink-0" />
                <span className="text-gray-300 text-sm">WhatsApp: 03329746471</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-8 text-center">
          <p className="text-gray-400 text-sm">
            &copy; {new Date().getFullYear()} AL-ZAHIR ETEA Coaching Academy. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
