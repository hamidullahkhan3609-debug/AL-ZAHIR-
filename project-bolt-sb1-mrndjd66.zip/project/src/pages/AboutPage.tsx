import { Target, Eye, MapPin, Award } from 'lucide-react';

export default function AboutPage() {
  return (
    <div>
      <section className="bg-gradient-to-r from-green-600 to-green-700 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">About AL-ZAHIR ETEA Coaching Academy</h1>
          <div className="w-24 h-1 bg-yellow-400 mx-auto"></div>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Background</h2>
              <div className="space-y-4 text-gray-600 leading-relaxed">
                <p>
                  AL-ZAHIR ETEA Coaching Academy is a premier educational institution located in Mama Khel, Bannu, Khyber Pakhtunkhwa, Pakistan. We specialize in preparing students for the Educational Testing and Evaluation Agency (ETEA) Center of Excellence scholarship test.
                </p>
                <p>
                  The ETEA scholarship test is conducted by the Government of Khyber Pakhtunkhwa to identify talented students and provide them with opportunities to study at top government institutions. Our academy focuses on Class 6 and Class 7 students, providing them with comprehensive preparation to excel in this competitive examination.
                </p>
                <p>
                  Founded with a commitment to educational excellence, AL-ZAHIR has become a trusted name in the region for ETEA test preparation. We combine experienced faculty, proven teaching methods, and modern facilities to ensure our students receive the best possible education.
                </p>
                <p>
                  Our curriculum is aligned with the Khyber Pakhtunkhwa Textbook Board syllabus, ensuring that students not only prepare for the scholarship test but also build a strong foundation in their regular studies.
                </p>
              </div>
            </div>

            <div className="space-y-6">
              <div className="bg-green-50 p-8 rounded-xl border-l-4 border-green-600">
                <div className="flex items-start space-x-4">
                  <div className="bg-green-600 p-3 rounded-lg">
                    <Target className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 mb-3">Our Mission</h3>
                    <p className="text-gray-600 leading-relaxed">
                      To prepare talented students from Mama Khel, Bannu, and surrounding areas for the ETEA Center of Excellence scholarship test, helping them secure admission to top government institutions and achieve their academic dreams.
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-yellow-50 p-8 rounded-xl border-l-4 border-yellow-400">
                <div className="flex items-start space-x-4">
                  <div className="bg-yellow-400 p-3 rounded-lg">
                    <Eye className="w-6 h-6 text-gray-900" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 mb-3">Our Vision</h3>
                    <p className="text-gray-600 leading-relaxed">
                      To become the leading ETEA coaching academy in Khyber Pakhtunkhwa, helping talented students from the area reach top institutions and empowering them to become future leaders and change-makers in their communities.
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-green-50 p-8 rounded-xl border-l-4 border-green-600">
                <div className="flex items-start space-x-4">
                  <div className="bg-green-600 p-3 rounded-lg">
                    <MapPin className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 mb-3">Our Location</h3>
                    <p className="text-gray-600 leading-relaxed">
                      Strategically located in Mama Khel, Bannu, we serve students from across the region. Our accessible location makes it convenient for students to attend classes and for those who need hostel facilities.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Core Values</h2>
            <div className="w-24 h-1 bg-yellow-400 mx-auto"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="font-bold text-gray-900 mb-2">Excellence</h3>
              <p className="text-gray-600 text-sm">Striving for the highest standards in education and student achievement</p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Target className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="font-bold text-gray-900 mb-2">Dedication</h3>
              <p className="text-gray-600 text-sm">Committed to helping every student reach their full potential</p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Eye className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="font-bold text-gray-900 mb-2">Integrity</h3>
              <p className="text-gray-600 text-sm">Maintaining honesty and strong moral principles in all we do</p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <MapPin className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="font-bold text-gray-900 mb-2">Community</h3>
              <p className="text-gray-600 text-sm">Serving our local community and nurturing future leaders</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
