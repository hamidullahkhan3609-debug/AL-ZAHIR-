import { BookOpen, GraduationCap } from 'lucide-react';

export default function ClassesPage() {
  const subjects = [
    {
      name: 'Urdu',
      description: 'Comprehensive study of Urdu language, literature, and grammar as per KPK Textbook Board syllabus',
      icon: '📖'
    },
    {
      name: 'English',
      description: 'English language skills, grammar, comprehension, and composition',
      icon: '🔤'
    },
    {
      name: 'Islamiyat',
      description: 'Islamic studies covering Quran, Hadith, and Islamic teachings',
      icon: '☪️'
    },
    {
      name: 'General Science',
      description: 'Introduction to scientific concepts, experiments, and natural phenomena',
      icon: '🔬'
    },
    {
      name: 'Mathematics',
      description: 'Mathematical concepts, problem-solving, and computational skills',
      icon: '🔢'
    }
  ];

  return (
    <div>
      <section className="bg-gradient-to-r from-green-600 to-green-700 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">Classes & Subjects</h1>
          <div className="w-24 h-1 bg-yellow-400 mx-auto mb-4"></div>
          <p className="text-xl text-green-50 max-w-2xl mx-auto">
            Comprehensive preparation for the ETEA Center of Excellence scholarship test
          </p>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Classes Offered</h2>
            <div className="w-24 h-1 bg-yellow-400 mx-auto mb-6"></div>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              We specialize in preparing students from Class 6 and Class 7 for the ETEA scholarship examination
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
            <div className="bg-gradient-to-br from-green-50 to-green-100 p-8 rounded-xl border-2 border-green-200 hover:border-green-400 transition-colors">
              <div className="flex items-center space-x-4 mb-4">
                <div className="bg-green-600 p-4 rounded-lg">
                  <GraduationCap className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900">Class 6</h3>
              </div>
              <p className="text-gray-700 leading-relaxed">
                Foundation-level preparation for students entering the scholarship track. We focus on building strong fundamentals across all subjects aligned with the ETEA test pattern and KPK Textbook Board curriculum.
              </p>
              <div className="mt-6">
                <p className="text-sm font-semibold text-green-700 mb-2">Key Focus Areas:</p>
                <ul className="text-sm text-gray-600 space-y-1 list-disc list-inside">
                  <li>Building strong subject fundamentals</li>
                  <li>Developing test-taking skills</li>
                  <li>Regular practice and assessments</li>
                  <li>Comprehensive concept coverage</li>
                </ul>
              </div>
            </div>

            <div className="bg-gradient-to-br from-yellow-50 to-yellow-100 p-8 rounded-xl border-2 border-yellow-200 hover:border-yellow-400 transition-colors">
              <div className="flex items-center space-x-4 mb-4">
                <div className="bg-yellow-500 p-4 rounded-lg">
                  <GraduationCap className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900">Class 7</h3>
              </div>
              <p className="text-gray-700 leading-relaxed">
                Advanced preparation for students in the final year before the ETEA scholarship test. Intensive focus on exam strategies, time management, and comprehensive subject mastery.
              </p>
              <div className="mt-6">
                <p className="text-sm font-semibold text-yellow-700 mb-2">Key Focus Areas:</p>
                <ul className="text-sm text-gray-600 space-y-1 list-disc list-inside">
                  <li>Advanced problem-solving techniques</li>
                  <li>Exam strategy and time management</li>
                  <li>Mock tests and performance analysis</li>
                  <li>Final preparation for scholarship test</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Subjects Taught</h2>
            <div className="w-24 h-1 bg-yellow-400 mx-auto mb-6"></div>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Our curriculum follows the Khyber Pakhtunkhwa Textbook Board Class 6 syllabus and covers all subjects required for the ETEA scholarship test
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {subjects.map((subject, index) => (
              <div
                key={index}
                className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow border-t-4 border-green-600"
              >
                <div className="text-4xl mb-4">{subject.icon}</div>
                <h3 className="text-xl font-bold text-gray-900 mb-3 flex items-center">
                  <BookOpen className="w-5 h-5 text-green-600 mr-2" />
                  {subject.name}
                </h3>
                <p className="text-gray-600 leading-relaxed">{subject.description}</p>
              </div>
            ))}
          </div>

          <div className="mt-12 bg-green-600 text-white p-8 rounded-xl">
            <div className="text-center">
              <h3 className="text-2xl font-bold mb-4">Teaching Methodology</h3>
              <div className="w-24 h-1 bg-yellow-400 mx-auto mb-6"></div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
                <div>
                  <h4 className="font-semibold mb-2">📚 Concept-Based Learning</h4>
                  <p className="text-green-50 text-sm">Focus on understanding core concepts rather than rote memorization</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">✅ Regular Assessments</h4>
                  <p className="text-green-50 text-sm">Daily, weekly, and monthly tests to track progress and identify areas for improvement</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">🎯 Personalized Attention</h4>
                  <p className="text-green-50 text-sm">Small class sizes ensuring individual attention to each student</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
