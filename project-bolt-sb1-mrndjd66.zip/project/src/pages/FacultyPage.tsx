import { User, Award, BookOpen } from 'lucide-react';

export default function FacultyPage() {
  const faculty = [
    {
      name: 'Zahir Gul Khan',
      role: 'Head of Academy',
      subjects: ['Islamiyat', 'Urdu', 'English'],
      description: 'Founder and Head of AL-ZAHIR ETEA Coaching Academy with extensive experience in ETEA test preparation. Specializes in Islamic studies, Urdu, and English language instruction.',
      expertise: 'Leadership, Curriculum Development, Islamic Studies, Languages'
    },
    {
      name: 'Noor Ayaz Khan',
      role: 'Senior Teacher',
      subjects: ['General Science'],
      description: 'Expert in General Science with a passion for making scientific concepts accessible and engaging for young learners. Focuses on practical understanding and application.',
      expertise: 'Scientific Teaching, Laboratory Work, Concept Clarity'
    },
    {
      name: 'Muhammad Niaz Khan',
      role: 'Mathematics Teacher',
      subjects: ['Mathematics'],
      description: 'Specialized in teaching mathematics with emphasis on problem-solving skills and logical reasoning. Helps students develop strong computational abilities.',
      expertise: 'Mathematical Problem Solving, Logical Reasoning, Competitive Exams'
    },
    {
      name: 'Sher Andaz Khan',
      role: 'Science Teacher',
      subjects: ['General Science'],
      description: 'Dedicated science educator committed to fostering curiosity and scientific thinking among students. Focuses on hands-on learning and real-world applications.',
      expertise: 'Experimental Learning, Scientific Inquiry, Student Engagement'
    }
  ];

  return (
    <div>
      <section className="bg-gradient-to-r from-green-600 to-green-700 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">Our Expert Faculty</h1>
          <div className="w-24 h-1 bg-yellow-400 mx-auto mb-4"></div>
          <p className="text-xl text-green-50 max-w-2xl mx-auto">
            Meet our dedicated team of educators committed to your success
          </p>
        </div>
      </section>

      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Experienced & Qualified Teachers</h2>
            <div className="w-24 h-1 bg-yellow-400 mx-auto mb-6"></div>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Our faculty members are carefully selected for their expertise, dedication, and proven track record in preparing students for the ETEA scholarship examination.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {faculty.map((teacher, index) => (
              <div
                key={index}
                className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow"
              >
                <div className="bg-gradient-to-r from-green-600 to-green-700 p-6 text-white">
                  <div className="flex items-start space-x-4">
                    <div className="bg-white bg-opacity-20 p-4 rounded-full">
                      <User className="w-12 h-12 text-white" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-2xl font-bold mb-1">{teacher.name}</h3>
                      <p className="text-green-100 font-medium">{teacher.role}</p>
                    </div>
                  </div>
                </div>

                <div className="p-6">
                  <div className="mb-4">
                    <div className="flex items-center space-x-2 mb-2">
                      <BookOpen className="w-5 h-5 text-green-600" />
                      <h4 className="font-semibold text-gray-900">Subjects:</h4>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {teacher.subjects.map((subject, idx) => (
                        <span
                          key={idx}
                          className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-medium"
                        >
                          {subject}
                        </span>
                      ))}
                    </div>
                  </div>

                  <p className="text-gray-600 leading-relaxed mb-4">
                    {teacher.description}
                  </p>

                  <div className="border-t pt-4">
                    <div className="flex items-center space-x-2 mb-2">
                      <Award className="w-5 h-5 text-yellow-500" />
                      <h4 className="font-semibold text-gray-900">Areas of Expertise:</h4>
                    </div>
                    <p className="text-gray-600 text-sm">{teacher.expertise}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-2xl p-8 md:p-12 border-2 border-green-200">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Why Our Faculty Stands Out</h2>
              <div className="w-24 h-1 bg-yellow-400 mx-auto"></div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="bg-green-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Award className="w-8 h-8 text-white" />
                </div>
                <h3 className="font-bold text-gray-900 mb-2">Qualified & Experienced</h3>
                <p className="text-gray-600 text-sm">
                  All teachers have proven experience in ETEA test preparation and subject matter expertise
                </p>
              </div>

              <div className="text-center">
                <div className="bg-green-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <BookOpen className="w-8 h-8 text-white" />
                </div>
                <h3 className="font-bold text-gray-900 mb-2">Student-Focused</h3>
                <p className="text-gray-600 text-sm">
                  Dedicated to individual student success with personalized attention and support
                </p>
              </div>

              <div className="text-center">
                <div className="bg-green-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <User className="w-8 h-8 text-white" />
                </div>
                <h3 className="font-bold text-gray-900 mb-2">Passionate Educators</h3>
                <p className="text-gray-600 text-sm">
                  Committed to inspiring students and fostering a love for learning
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
