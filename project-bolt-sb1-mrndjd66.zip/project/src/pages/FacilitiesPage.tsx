import { ClipboardCheck, Home, Users, BookOpen, Award, Calendar } from 'lucide-react';

export default function FacilitiesPage() {
  return (
    <div>
      <section className="bg-gradient-to-r from-green-600 to-green-700 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">Our Facilities</h1>
          <div className="w-24 h-1 bg-yellow-400 mx-auto mb-4"></div>
          <p className="text-xl text-green-50 max-w-2xl mx-auto">
            Modern infrastructure and comprehensive support for student success
          </p>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-gradient-to-br from-green-50 to-green-100 p-8 rounded-xl border-2 border-green-200">
              <div className="flex items-start space-x-4 mb-6">
                <div className="bg-green-600 p-4 rounded-lg">
                  <ClipboardCheck className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-2">Regular Testing & Assessments</h2>
                  <p className="text-green-700 font-medium">Comprehensive evaluation system</p>
                </div>
              </div>
              <div className="space-y-4">
                <div className="bg-white p-4 rounded-lg shadow-sm">
                  <div className="flex items-center space-x-3 mb-2">
                    <Calendar className="w-5 h-5 text-green-600" />
                    <h3 className="font-semibold text-gray-900">Daily Tests</h3>
                  </div>
                  <p className="text-gray-600 text-sm">
                    Quick assessments to reinforce daily learning and identify areas needing immediate attention
                  </p>
                </div>
                <div className="bg-white p-4 rounded-lg shadow-sm">
                  <div className="flex items-center space-x-3 mb-2">
                    <Calendar className="w-5 h-5 text-green-600" />
                    <h3 className="font-semibold text-gray-900">Weekly Tests</h3>
                  </div>
                  <p className="text-gray-600 text-sm">
                    Comprehensive weekly evaluations covering topics taught during the week
                  </p>
                </div>
                <div className="bg-white p-4 rounded-lg shadow-sm">
                  <div className="flex items-center space-x-3 mb-2">
                    <Calendar className="w-5 h-5 text-green-600" />
                    <h3 className="font-semibold text-gray-900">Monthly Tests</h3>
                  </div>
                  <p className="text-gray-600 text-sm">
                    Full-scale examinations simulating ETEA test conditions and format
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-yellow-50 to-yellow-100 p-8 rounded-xl border-2 border-yellow-200">
              <div className="flex items-start space-x-4 mb-6">
                <div className="bg-yellow-500 p-4 rounded-lg">
                  <Home className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-2">Hostel Facility</h2>
                  <p className="text-yellow-700 font-medium">Comfortable accommodation for students</p>
                </div>
              </div>
              <div className="space-y-4">
                <div className="bg-white p-4 rounded-lg shadow-sm">
                  <div className="flex items-center space-x-3 mb-2">
                    <Users className="w-5 h-5 text-yellow-600" />
                    <h3 className="font-semibold text-gray-900">Capacity: 20-30 Students</h3>
                  </div>
                  <p className="text-gray-600 text-sm">
                    Well-maintained hostel facilities accommodating 20 to 30 students with all necessary amenities
                  </p>
                </div>
                <div className="bg-white p-4 rounded-lg shadow-sm">
                  <div className="flex items-center space-x-3 mb-2">
                    <Home className="w-5 h-5 text-yellow-600" />
                    <h3 className="font-semibold text-gray-900">Separate Accommodation</h3>
                  </div>
                  <p className="text-gray-600 text-sm">
                    Separate and secure accommodation facilities for male and female students
                  </p>
                </div>
                <div className="bg-white p-4 rounded-lg shadow-sm">
                  <div className="flex items-center space-x-3 mb-2">
                    <Users className="w-5 h-5 text-yellow-600" />
                    <h3 className="font-semibold text-gray-900">Full Support Services</h3>
                  </div>
                  <p className="text-gray-600 text-sm">
                    Comprehensive support including meals, supervision, and a conducive study environment
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Additional Facilities</h2>
            <div className="w-24 h-1 bg-yellow-400 mx-auto"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
              <div className="bg-green-100 w-14 h-14 rounded-full flex items-center justify-center mb-4">
                <BookOpen className="w-7 h-7 text-green-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Well-Equipped Classrooms</h3>
              <p className="text-gray-600">
                Modern classrooms with proper seating, lighting, and teaching aids to facilitate effective learning
              </p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
              <div className="bg-green-100 w-14 h-14 rounded-full flex items-center justify-center mb-4">
                <Award className="w-7 h-7 text-green-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Focused ETEA Preparation</h3>
              <p className="text-gray-600">
                Specialized curriculum and teaching methods specifically designed for ETEA scholarship examination success
              </p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
              <div className="bg-green-100 w-14 h-14 rounded-full flex items-center justify-center mb-4">
                <Users className="w-7 h-7 text-green-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Small Class Sizes</h3>
              <p className="text-gray-600">
                Limited students per class ensuring personalized attention and effective teacher-student interaction
              </p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
              <div className="bg-green-100 w-14 h-14 rounded-full flex items-center justify-center mb-4">
                <BookOpen className="w-7 h-7 text-green-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Study Materials</h3>
              <p className="text-gray-600">
                Comprehensive study materials, practice papers, and reference books aligned with ETEA syllabus
              </p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
              <div className="bg-green-100 w-14 h-14 rounded-full flex items-center justify-center mb-4">
                <ClipboardCheck className="w-7 h-7 text-green-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Performance Tracking</h3>
              <p className="text-gray-600">
                Regular progress reports and parent-teacher meetings to monitor and improve student performance
              </p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
              <div className="bg-green-100 w-14 h-14 rounded-full flex items-center justify-center mb-4">
                <Home className="w-7 h-7 text-green-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Safe Environment</h3>
              <p className="text-gray-600">
                Secure and supervised environment ensuring student safety and well-being at all times
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-gradient-to-r from-green-600 to-green-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold mb-6">Why Our Facilities Matter</h2>
            <div className="w-24 h-1 bg-yellow-400 mx-auto mb-8"></div>
            <p className="text-xl text-green-50 max-w-3xl mx-auto leading-relaxed">
              We believe that quality facilities are essential for quality education. Our comprehensive facilities ensure that students have everything they need to focus on their studies and achieve their academic goals. From regular assessments to comfortable accommodation, we provide a complete ecosystem for student success.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
