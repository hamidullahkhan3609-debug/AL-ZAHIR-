import { Award, BookOpen, Users, Target, TrendingUp, Building2 } from 'lucide-react';

interface HomePageProps {
  onNavigate: (page: string) => void;
}

export default function HomePage({ onNavigate }: HomePageProps) {
  return (
    <div>
      <section className="relative bg-gradient-to-br from-green-700 via-green-600 to-green-800 text-white py-20 sm:py-32">
        <div className="absolute inset-0 bg-black opacity-10"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold mb-6">
            Welcome to AL-ZAHIR ETEA Coaching Academy
          </h1>
          <p className="text-xl sm:text-2xl mb-8 text-green-50 max-w-3xl mx-auto">
            Empowering students to excel in the ETEA Center of Excellence scholarship test
          </p>
          <p className="text-lg mb-10 text-green-100 max-w-2xl mx-auto">
            Located in Mama Khel, Bannu, Khyber Pakhtunkhwa, we prepare Class 6 and Class 7 students for admission to top government institutions
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => { onNavigate('contact'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
              className="bg-yellow-400 text-gray-900 px-8 py-4 rounded-lg font-semibold text-lg hover:bg-yellow-300 transition-all transform hover:scale-105 shadow-lg"
            >
              Apply Now
            </button>
            <button
              onClick={() => { onNavigate('about'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
              className="bg-white text-green-700 px-8 py-4 rounded-lg font-semibold text-lg hover:bg-green-50 transition-all transform hover:scale-105 shadow-lg"
            >
              Learn More
            </button>
          </div>
        </div>
      </section>

      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">Our Mission</h2>
            <div className="w-24 h-1 bg-yellow-400 mx-auto mb-6"></div>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto leading-relaxed">
              AL-ZAHIR ETEA Coaching Academy is dedicated to preparing talented students for the Educational Testing and Evaluation Agency (ETEA) Center of Excellence scholarship test conducted by the Government of Khyber Pakhtunkhwa. Our goal is to help students secure admission to top government institutions through comprehensive preparation and guidance.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow border-t-4 border-green-600">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mb-6">
                <Award className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Excellence in Education</h3>
              <p className="text-gray-600 leading-relaxed">
                We provide top-quality education focused on the ETEA scholarship test curriculum, ensuring students are thoroughly prepared.
              </p>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow border-t-4 border-yellow-400">
              <div className="bg-yellow-100 w-16 h-16 rounded-full flex items-center justify-center mb-6">
                <Users className="w-8 h-8 text-yellow-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Expert Faculty</h3>
              <p className="text-gray-600 leading-relaxed">
                Our experienced teachers are dedicated to nurturing talent and helping students achieve their academic goals.
              </p>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow border-t-4 border-green-600">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mb-6">
                <Target className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Focused Preparation</h3>
              <p className="text-gray-600 leading-relaxed">
                Regular tests and assessments ensure students are exam-ready and confident in their abilities.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">Why Choose Us?</h2>
            <div className="w-24 h-1 bg-yellow-400 mx-auto"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="flex items-start space-x-4 p-6 bg-green-50 rounded-lg">
              <BookOpen className="w-8 h-8 text-green-600 flex-shrink-0 mt-1" />
              <div>
                <h4 className="font-semibold text-gray-900 mb-2">Comprehensive Curriculum</h4>
                <p className="text-gray-600">Complete coverage of all subjects required for the ETEA scholarship test</p>
              </div>
            </div>

            <div className="flex items-start space-x-4 p-6 bg-green-50 rounded-lg">
              <TrendingUp className="w-8 h-8 text-green-600 flex-shrink-0 mt-1" />
              <div>
                <h4 className="font-semibold text-gray-900 mb-2">Proven Track Record</h4>
                <p className="text-gray-600">Consistent success in helping students secure scholarships</p>
              </div>
            </div>

            <div className="flex items-start space-x-4 p-6 bg-green-50 rounded-lg">
              <Building2 className="w-8 h-8 text-green-600 flex-shrink-0 mt-1" />
              <div>
                <h4 className="font-semibold text-gray-900 mb-2">Modern Facilities</h4>
                <p className="text-gray-600">Well-equipped classrooms and hostel accommodation available</p>
              </div>
            </div>

            <div className="flex items-start space-x-4 p-6 bg-green-50 rounded-lg">
              <Award className="w-8 h-8 text-green-600 flex-shrink-0 mt-1" />
              <div>
                <h4 className="font-semibold text-gray-900 mb-2">Regular Assessments</h4>
                <p className="text-gray-600">Daily, weekly, and monthly tests to track progress</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-gradient-to-r from-green-600 to-green-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl sm:text-4xl font-bold mb-6">Ready to Start Your Journey?</h2>
          <p className="text-xl mb-8 text-green-50 max-w-2xl mx-auto">
            Join AL-ZAHIR ETEA Coaching Academy and take the first step towards securing your place in a top government institution.
          </p>
          <button
            onClick={() => { onNavigate('contact'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
            className="bg-yellow-400 text-gray-900 px-8 py-4 rounded-lg font-semibold text-lg hover:bg-yellow-300 transition-all transform hover:scale-105 shadow-lg"
          >
            Contact Us Today
          </button>
        </div>
      </section>
    </div>
  );
}
